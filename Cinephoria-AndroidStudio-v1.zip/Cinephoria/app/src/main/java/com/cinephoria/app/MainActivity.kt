package com.cinephoria.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val Neon = Color(0xFFB56CFF)
private val Neon2 = Color(0xFF7A2CFF)
private val Dark = Color(0xFF08070B)
private val Card = Color(0xFF15121B)
private val LightBg = Color(0xFFF7F5FA)
private val LightCard = Color(0xFFFFFFFF)

data class Media(
    val id: Int,
    val title: String,
    val subtitle: String,
    val type: String,
    val genre: String,
    val rating: String,
    val year: String,
    val colorA: Color,
    val colorB: Color
)

private val demo = listOf(
    Media(1, "شبِ نئونی", "Neon Night", "فیلم", "جنایی", "8.7", "2026", Color(0xFF5B21B6), Color(0xFFEC4899)),
    Media(2, "آخرین مدار", "Last Orbit", "سریال", "علمی‌تخیلی", "9.1", "2026", Color(0xFF0F766E), Color(0xFF2563EB)),
    Media(3, "سایه‌روشن", "Chiaroscuro", "فیلم", "درام", "8.3", "2025", Color(0xFF111827), Color(0xFF7C3AED)),
    Media(4, "سامورایی صفر", "Samurai Zero", "انیمه", "اکشن", "9.0", "2025", Color(0xFF9F1239), Color(0xFFF59E0B)),
    Media(5, "خط قرمز", "Red Line", "سریال", "هیجانی", "8.5", "2026", Color(0xFF7F1D1D), Color(0xFFF97316)),
    Media(6, "آرکادیا", "Arcadia", "فیلم", "فانتزی", "8.8", "2026", Color(0xFF164E63), Color(0xFF06B6D4))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CinephoriaApp() }
    }
}

@Composable
fun CinephoriaApp() {
    var dark by remember { mutableStateOf(true) }
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            primary = Neon,
            secondary = Neon2,
            background = Dark,
            surface = Card,
            onBackground = Color.White
        ) else lightColorScheme(
            primary = Neon2,
            secondary = Neon,
            background = LightBg,
            surface = LightCard
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            val nav = rememberNavController()
            NavHost(navController = nav, startDestination = "home") {
                composable("home") { Home(nav, dark) }
                composable("search") { Search(nav) }
                composable("favorites") { Favorites(nav) }
                composable("downloads") { Downloads(nav) }
                composable("profile") { Profile(nav, dark) { dark = !dark } }
                composable("detail/{id}") { back ->
                    val id = back.arguments?.getString("id")?.toIntOrNull() ?: 1
                    Detail(nav, demo.firstOrNull { it.id == id } ?: demo.first())
                }
            }
        }
    }
}

@Composable
fun Shell(nav: NavHostController, selected: String, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                val items = listOf(
                    Triple("home", "خانه", Icons.Default.Home),
                    Triple("search", "جستجو", Icons.Default.Search),
                    Triple("favorites", "علاقه‌مندی", Icons.Default.FavoriteBorder),
                    Triple("downloads", "دانلودها", Icons.Default.Download),
                    Triple("profile", "پروفایل", Icons.Default.Person)
                )
                items.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = selected == route,
                        onClick = { nav.navigate(route) { launchSingleTop = true } },
                        icon = { Icon(icon, null) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Neon,
                            selectedTextColor = Neon,
                            indicatorColor = Neon.copy(alpha = .14f)
                        )
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        Column(
            modifier = Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp),
            content = content
        )
    }
}

@Composable
fun Home(nav: NavHostController, dark: Boolean) {
    Shell(nav, "home") {
        Row(
            Modifier.fillMaxWidth().padding(top = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("CINEPHORIA", color = Neon, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("دنیای سینما، همین‌جا", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(.6f))
            }
            IconButton(onClick = { nav.navigate("profile") }) {
                Icon(Icons.Default.AccountCircle, "پروفایل", tint = Neon)
            }
        }
        Spacer(Modifier.height(18.dp))
        HeroCard(demo[0]) { nav.navigate("detail/1") }
        SectionTitle("ادامه تماشا", "نمایش همه")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(demo.take(4)) { m -> MiniCard(m) { nav.navigate("detail/${m.id}") } }
        }
        SectionTitle("ترندهای امروز", "بیشترین بازدید")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(demo.shuffled().take(5)) { m -> PosterCard(m) { nav.navigate("detail/${m.id}") } }
        }
        SectionTitle("جدیدترین‌ها", "همه")
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {
            items(demo) { m -> ListCard(m) { nav.navigate("detail/${m.id}") } }
        }
    }
}

@Composable
fun HeroCard(m: Media, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(m.colorA, m.colorB)))
            .clickable(onClick = onClick).padding(22.dp)
    ) {
        Column(Modifier.align(Alignment.BottomStart)) {
            Text("پیشنهاد ویژه", color = Color.White.copy(.8f), fontSize = 12.sp)
            Text(m.title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("${m.year}  •  ${m.genre}  •  ⭐ ${m.rating}", color = Color.White.copy(.9f))
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
            ) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("جزئیات") }
        }
    }
}

@Composable
fun SectionTitle(title: String, action: String) {
    Row(
        Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(action, color = Neon, fontSize = 12.sp)
    }
}

@Composable
fun MiniCard(m: Media, onClick: () -> Unit) {
    Column(Modifier.width(150.dp).clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().height(92.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.horizontalGradient(listOf(m.colorA, m.colorB)))
        ) {
            Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
            LinearProgressIndicator(
                progress = { .58f },
                modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
                color = Neon,
                trackColor = Color.White.copy(.25f)
            )
        }
        Spacer(Modifier.height(7.dp))
        Text(m.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("قسم ${m.type}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(.55f))
    }
}

@Composable
fun PosterCard(m: Media, onClick: () -> Unit) {
    Column(Modifier.width(125.dp).clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().height(175.dp).clip(RoundedCornerShape(18.dp))
                .background(Brush.verticalGradient(listOf(m.colorB, m.colorA)))
        ) {
            Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                Text(m.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2)
                Text("⭐ ${m.rating}", color = Color.White.copy(.9f), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(m.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ListCard(m: Media, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(width = 72.dp, height = 82.dp).clip(RoundedCornerShape(12.dp))
                .background(Brush.verticalGradient(listOf(m.colorA, m.colorB)))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(m.title, fontWeight = FontWeight.Bold)
            Text("${m.type} • ${m.genre} • ${m.year}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
            Text("⭐ ${m.rating}", color = Neon, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronLeft, null, tint = MaterialTheme.colorScheme.onSurface.copy(.5f))
    }
}

@Composable
fun Search(nav: NavHostController) {
    Shell(nav, "search") {
        Text("جستجو", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 20.dp))
        var q by remember { mutableStateOf("") }
        OutlinedTextField(
            value = q, onValueChange = { q = it },
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
            placeholder = { Text("نام فیلم، سریال یا انیمه...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(18.dp)
        )
        val results = if (q.isBlank()) demo else demo.filter { "${it.title} ${it.subtitle} ${it.genre}".contains(q, true) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(results) { m -> ListCard(m) { nav.navigate("detail/${m.id}") } }
        }
    }
}

@Composable
fun Favorites(nav: NavHostController) {
    Shell(nav, "favorites") {
        Text("علاقه‌مندی‌ها", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 20.dp, bottom = 14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(demo.take(3)) { m -> ListCard(m) { nav.navigate("detail/${m.id}") } }
        }
    }
}

@Composable
fun Downloads(nav: NavHostController) {
    Shell(nav, "downloads") {
        Text("دانلودها", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 20.dp))
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.DownloadForOffline, null, tint = Neon, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(12.dp))
                Text("هنوز چیزی دانلود نکرده‌ای")
                Text("دانلودهای آفلاین اینجا نمایش داده می‌شوند.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(.55f))
            }
        }
    }
}

@Composable
fun Profile(nav: NavHostController, dark: Boolean, toggle: () -> Unit) {
    Shell(nav, "profile") {
        Text("پروفایل", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 20.dp))
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface).padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(62.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Neon2, Neon)))) {
                Text("C", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.Center))
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("کاربر Cinephoria", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("حساب محلی • بدون سرور", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
            }
        }
        Spacer(Modifier.height(16.dp))
        SettingRow("حالت شب", if (dark) "فعال" else "غیرفعال", Icons.Default.DarkMode, toggle)
        SettingRow("زبان", "فارسی (RTL)", Icons.Default.Language) {}
        SettingRow("نسخه", "1.0.0", Icons.Default.Info) {}
    }
}

@Composable
fun SettingRow(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Neon)
        Spacer(Modifier.width(14.dp))
        Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(.55f))
        Spacer(Modifier.width(8.dp))
        Icon(Icons.Default.ChevronLeft, null, tint = MaterialTheme.colorScheme.onBackground.copy(.35f))
    }
}

@Composable
fun Detail(nav: NavHostController, m: Media) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("جزئیات") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowForward, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(bottom = 30.dp)) {
            item {
                Box(
                    Modifier.fillMaxWidth().height(330.dp).clip(RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp))
                        .background(Brush.verticalGradient(listOf(m.colorB, m.colorA)))
                ) {
                    Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
                        Text(m.title, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                        Text("${m.year}  •  ${m.type}  •  ${m.genre}  •  ⭐ ${m.rating}", color = Color.White.copy(.9f))
                    }
                }
            }
            item {
                Column(Modifier.padding(18.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {}, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("پخش")
                        }
                        OutlinedButton(onClick = {}, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Download, null); Spacer(Modifier.width(5.dp)); Text("دانلود")
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("درباره اثر", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Text(
                        "یک اثر نمایشی نمونه برای نسخه اولیه Cinephoria. این صفحه برای اتصال بعدی به API، دیتابیس و سیستم پخش ویدیو آماده شده است.",
                        color = MaterialTheme.colorScheme.onBackground.copy(.72f),
                        lineHeight = 24.sp
                    )
                    Spacer(Modifier.height(18.dp))
                    Text("اطلاعات", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("امتیاز کاربران: ${m.rating}\nژانر: ${m.genre}\nسال انتشار: ${m.year}\nنوع: ${m.type}", lineHeight = 25.sp)
                }
            }
        }
    }
}
